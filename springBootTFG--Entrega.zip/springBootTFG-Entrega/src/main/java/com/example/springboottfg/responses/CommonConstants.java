package com.example.springboottfg.responses;

public class CommonConstants {

    public static final String SUCCESS = "SUCCESS";

    public static final String CREATED = "CREATED";

    public static final String ERROR = "ERROR";

    public static final String OK = "OK";

    public static final String UTF_8 = "UTF_8";


}
