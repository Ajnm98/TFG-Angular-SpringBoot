package com.example.springboottfg.models;

public enum EProvider {
    LOCAL, GOOGLE
}
