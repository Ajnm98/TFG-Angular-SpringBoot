package com.example.springboottfg.repository;

import com.example.springboottfg.models.Taller;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TallerRepository extends JpaRepository<Taller, Long> {


}
