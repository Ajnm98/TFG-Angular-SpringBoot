package com.example.springboottfg.controllers;


import org.springframework.stereotype.Controller;

@Controller
public class GestionClienteController {
}
