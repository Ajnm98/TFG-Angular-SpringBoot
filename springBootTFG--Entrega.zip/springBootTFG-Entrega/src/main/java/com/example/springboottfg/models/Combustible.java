package com.example.springboottfg.models;

public enum Combustible {
    Gasolina, Diesel, Electrico, Hibrido
}
