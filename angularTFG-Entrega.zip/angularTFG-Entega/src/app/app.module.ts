import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AuthModule } from './auth/auth.module';
import { PagesModule } from './pages/pages.module';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule } from 'ngx-bootstrap/modal';


import { AppComponent } from './app.component';
import { NopagefoundComponent } from './nopagefound/nopagefound.component';
import { ToastrModule } from 'ngx-toastr';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {FullCalendarModule} from "@fullcalendar/angular";
import {MatSlideToggleModule} from "@angular/material/slide-toggle";
import {MatLegacyFormFieldModule} from "@angular/material/legacy-form-field";
import {MatSelectModule} from "@angular/material/select";
import {NgxPayPalModule} from "ngx-paypal";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    NopagefoundComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    PagesModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    FullCalendarModule,
    MatSlideToggleModule,
    MatLegacyFormFieldModule,
    MatSelectModule,
    BrowserAnimationsModule,
    PagesModule,
    ToastrModule.forRoot(),
    NgxPayPalModule,
    AuthModule,
    ModalModule.forRoot(),
    NgbModule
  ],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
