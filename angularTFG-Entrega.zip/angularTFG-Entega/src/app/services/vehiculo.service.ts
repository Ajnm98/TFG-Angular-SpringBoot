import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../environments/environment";
import {catchError, map, of} from "rxjs";
import {
  vehiculoUsuario,
  vehiculoCrear,
  VehiculoUsuario,
  vehiculoBorrar, vehiculoUsuariolista
} from "../interfaces/interfaceVehiculo";

@Injectable({
  providedIn: 'root'
})
export class VehiculoService {

  public vehiculoUsuariolista!: VehiculoUsuario[];

  public vehiculoUsuarios!: VehiculoUsuario[];

  private baseUrl: string = environment.baseUrl;


  constructor(private http: HttpClient) {
  }

  crearVehiculo(tipoVehiculo?: string, modeloVehiculo?: string, fecha_creacion?: Date, tipoCombustible?: string, matricula?: string, id?: number) {
    const url = `${this.baseUrl}/vehiculo/crear/${id}`;
    const body = {tipoVehiculo, modeloVehiculo, fecha_creacion, tipoCombustible, matricula};

    return this.http.post<vehiculoCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }

  editarVehiculo(tipoVehiculo?: string, modeloVehiculo?: string, fecha_creacion?: Date, tipoCombustible?: string, matricula?: string, id?: number) {
    const url = `${this.baseUrl}/vehiculo/editar/${id}`;
    const body = {tipoVehiculo, modeloVehiculo, fecha_creacion, tipoCombustible, matricula};

    return this.http.post<vehiculoCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }

  obtenerVehiculo(id?: number) {
    const url = `${this.baseUrl}/vehiculo/obtenerPorUsuario/${id}`;

    return this.http.get<vehiculoUsuario>(url)
      .pipe(
        map(resp => {
          console.log(this.vehiculoUsuarios);
          console.log(resp);
          this.vehiculoUsuarios = resp.vehiculoUsuario!;
          return resp.vehiculoUsuario?.length != 0

        }),
        catchError(err => of(false))
      );
  }

  obtenerVehiculoid(id?: number) {
    const url = `${this.baseUrl}/vehiculo/obtenerVehiculo/${id}`;

    return this.http.get(url)
      .pipe(map (resp => {
          // console.log(resp);
          return resp;
        }),
        catchError(error => of(false)))
      ;
  }


  borrarVehiculo(id: number) {
    const url = `${this.baseUrl}/vehiculo/eliminarPorId/${id}`;
    return this.http.delete<vehiculoBorrar>(url)
      .pipe(
        map(resp => {
          return resp.status != null;
        }),
        catchError(err => of(false))
      );
  }

}
