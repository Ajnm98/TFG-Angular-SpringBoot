import {catchError, map, of} from "rxjs";
import {Injectable} from "@angular/core";
import {environment} from "../../environments/environment";
import {HttpClient} from "@angular/common/http";
import {citaCrear, citas, citasObtener, citasObtenerUsuario, citasUsuario} from "../interfaces/inferfaceCitas";
import {vehiculoBorrar} from "../interfaces/interfaceVehiculo";
import {AuthService} from "../auth/service/auth.service";
import {mecanicoCrear} from "../interfaces/interfaceMecanico";

@Injectable({
  providedIn: 'root'
})
export class CitaService {


  private id = this.authService.user.id;

  private baseUrl: string = environment.baseUrl;

  public CitasObtener!: citas[];
  public CitasObtenerUsuario!: citasUsuario[];


  constructor(private http: HttpClient,private authService: AuthService) {
  }


  crearCita(title?: string, start?: Date, end?: Date, mecanico?: number, estandar?: number) {
    const id_usuario = this.authService.user.id;
    const url = `${this.baseUrl}/cita/crear/${id_usuario}/${mecanico}/${estandar}`;
    const body = {title, start, end};

    return this.http.post<citaCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }

  obtenerCitasUsuario() {
    const url = `${this.baseUrl}/cita/obtenerPorUsuario/${this.id}`;
    return this.http.get<citasObtenerUsuario>(url)
      .pipe(
        map(resp => {
          console.log(this.CitasObtenerUsuario);
          console.log(resp);
          this.CitasObtenerUsuario = resp.citasObtenerUsuario!;
          return resp.citasObtenerUsuario?.length != 0

        }),
        catchError(err => of(false))
      );
  }

  obtenerCitas() {
    const url = `${this.baseUrl}/cita/obtener/${this.id}`;

    return this.http.get<citasObtener>(url)
      .pipe(
        map(resp => {
          console.log(this.CitasObtener);
          console.log(resp);
          this.CitasObtener = resp.citasObtener!;
          return resp.citasObtener?.length != 0

        }),
        catchError(err => of(false))
      );
  }

  borrarcita(id: string) {
    const url = `${this.baseUrl}/cita/eliminarPorId/${id}`;
    return this.http.delete<citaCrear>(url)
      .pipe(
        map(resp => {
          return resp.status != null;
        }),
        catchError(err => of(false))
      );
  }

  updateCitas(id?: number) {
    const url = `${this.baseUrl}/cita/editartienda`;
    const body = {id};

    return this.http.post<citaCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }

  updateCitaspagado(id?: number) {
    const url = `${this.baseUrl}/cita/editarpagado`;
    const body = {id};

    return this.http.post<citaCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }

}
