import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, of } from 'rxjs';
import { environment } from 'src/environment/environment';
import {EstandarReparacion, createEstandar, listarEstandares} from '../interfaces/reparacionesI';

@Injectable({
  providedIn: 'root'
})
export class ReparacionesService {

  private baseUrl: string = environment.baseUrl;

  private todosEstandares?: EstandarReparacion[] | null;
  private todosEstandaresCitas?: EstandarReparacion[] | null;

  get listaEstandar(){
    return this.todosEstandares;
  }

  get listaEstandarCitas(){
    return this.todosEstandaresCitas;
  }

  constructor(private http: HttpClient) { }


  crearEstandar(nombre:string, descripcion:string, precio_estimado:number,
               duracion_estimada:string): Observable<boolean>{
    const url = `${this.baseUrl}/api/reparaciones/create`;
    const body = {nombre, descripcion, precio_estimado, duracion_estimada};

    return this.http.post<createEstandar>(url,body)
      .pipe(
        map(res => {
          console.log("el nombre es " + nombre);
          console.log(res.status);
          return res.data!=null
        }),
        catchError(err => {
          console.log(err);
           return of (false);})
      )
  }


  eliminarEstandar(id: number): Observable<boolean> {
    const url = `${this.baseUrl}/api/reparaciones/${id}`;

    return this.http.delete<createEstandar>(url)
      .pipe(
        map(res => {
          console.log(res.status);
          return res.message == "OK";
        }),
        catchError(err => of(false))
      );
  }

  listarEstandares(): Observable<boolean>{
    const url = `${this.baseUrl}/api/reparaciones`;

    return this.http.get<listarEstandares>(url)
    .pipe(
      map(res => {
        this.todosEstandares = res.data;
        console.log(this.todosEstandares);
        console.log(res.status);
        return res.status == "SUCCESS";
      }),
    catchError(err => of(false))
    )
}

  listarEstandaresCitas(): Observable<boolean>{
    const url = `${this.baseUrl}/api/reparaciones`;

    return this.http.get<listarEstandares>(url)
      .pipe(
        map(res => {
          this.todosEstandaresCitas = res.data;
          console.log(this.todosEstandaresCitas);
          console.log(res.status);
          return res.status == "SUCCESS";
        }),
        catchError(err => of(false))
      )
  }





actualizarEstandar(id: number,  nombre:string, descripcion:string, precio_estimado:number,
  duracion_estimada:string): Observable<boolean>{
  const url = `${this.baseUrl}/api/reparaciones/${id}`;
  const body = {nombre, descripcion, precio_estimado, duracion_estimada};

  return this.http.put<createEstandar>(url,body)
  .pipe(
    map(res => {
      console.log(res.status);
      return res.status == "SUCCESS";
    }),
  catchError(err => of(false))
  )
}




}
