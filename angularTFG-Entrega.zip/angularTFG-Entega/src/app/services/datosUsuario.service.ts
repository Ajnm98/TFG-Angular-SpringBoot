import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, catchError, map, of } from "rxjs";
import { environment } from "src/environment/environment";
import { Usuario } from "../auth/interfaces/interface";
import { DatosUsuario } from "../interfaces/interfaceDatosUsuario";

@Injectable({providedIn: 'root'})
export class DatosUsuarioService {

    private baseUrl: string = environment.baseUrl;
    user: Usuario;

    constructor(private http: HttpClient){

    }

    completarRegistro(nombre: string, apellidos: string, dni: string, direccion: string, telefono: string, id: number){

        const url = `${this.baseUrl}/datos-usuario/crear/${id}`;
        const body = {nombre, apellidos, dni, direccion, telefono, id};

        return this.http.post(url, body)
        .pipe(map (resp => {
            console.log(resp);
            return resp;
        }),
        catchError(error => of(false)))

    }

    getDatosUsuario(id: number){
        const url = `${this.baseUrl}/datos-usuario/buscar/${id}`;
        return this.http.get(url)
        .pipe(map (resp => {
            console.log(resp);
            return resp;
        }),
        catchError(error => of(false)))
    }

    updateDatosUsuario(nombre: string, apellidos: string, dni: string, direccion: string, telefono: string, id:number){
        const url = `${this.baseUrl}/datos-usuario/modificar/${id}`;
        const body = {nombre, apellidos, dni, direccion, telefono, id};

        return this.http.put(url, body)
            .pipe( map (resp => {
                console.log(resp);
                return resp;
            }), catchError(error => of(false)))


    }



}