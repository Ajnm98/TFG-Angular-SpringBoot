import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../environments/environment";
import {catchError, map, of} from "rxjs";
import {
  usuario,
  usuarioCrear,
  usuariolista,
  usuarioListaId,
  usuarioObtener
} from "../interfaces/interfaceUsuario";
import {Noticiasmodelo} from "../pages/noticias/noticiasmodelo";
import {mecanicolista, mecanicoListaId} from "../interfaces/interfaceMecanico";
import {vehiculoCrear} from "../interfaces/interfaceVehiculo";


@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  public usuariolistaId!: usuario[];

  public usuariolistas!: usuario[];


  private baseUrl: string = environment.baseUrl;


  constructor(private http: HttpClient) {
  }




  obtenerUsuarios() {
    const url = `${this.baseUrl}/usuario/obtenerTodos`;

    return this.http.get<usuarioObtener>(url)
      .pipe(
        map(resp => {
          console.log(this.usuariolistas);
          console.log(resp);
          this.usuariolistas = resp.usuarioObtener!;
          return resp.usuarioObtener?.length != 0

        }),
        catchError(err => of(false))
      );
  }

  borrarUsuario(id: number) {
    const url = `${this.baseUrl}/usuario/eliminarUsuarioId/${id}`;
    return this.http.delete<usuarioCrear>(url)
      .pipe(
        map(resp => {
          return resp.status != null;
        }),
        catchError(err => of(false))
      );
  }

  obtenerUsuarioid(id?: number) {
    const url = `${this.baseUrl}/usuario/obtenerUsuario/${id}`;

    return this.http.get<usuarioListaId>(url)
      .pipe(
        map(resp => {
          console.log(this.usuariolistaId);
          console.log(resp);
          this.usuariolistaId = resp.usuarioListaId!;
          return resp.usuarioListaId?.length != 0

        }),
        catchError(err => of(false))
      );
  }

  editarUsuario(username?: string, password?: string, email?: string, id?: number) {
    const url = `${this.baseUrl}/usuario/editarUsuario/${id}`;
    const body = {id,username, password, email};

    return this.http.post<usuarioCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }


}
