import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../environments/environment";
import {catchError, map, of} from "rxjs";
import {
  noticias,
  noticiasCrear,
  noticiaslista,
  noticiasListaId,
  noticiasObtener
} from "../interfaces/interfaceNoticias";
import {Noticiasmodelo} from "../pages/noticias/noticiasmodelo";
import {mecanicolista, mecanicoListaId} from "../interfaces/interfaceMecanico";
import {vehiculoCrear} from "../interfaces/interfaceVehiculo";


@Injectable({
  providedIn: 'root'
})
export class NoticiasService {

  public noticiaslistaId!: noticias[];

  public noticiaslistas!: noticias[];


  private baseUrl: string = environment.baseUrl;


  constructor(private http: HttpClient) {
  }

  crearNoticias(titular?: string, cuerpo?: string) {
    const url = `${this.baseUrl}/noticias/crear`;
    const body = {titular, cuerpo};

    return this.http.post<noticiasCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }



  obtenerNoticias() {
    const url = `${this.baseUrl}/noticias/obtenernoticias`;

    return this.http.get<noticiasObtener>(url)
      .pipe(
        map(resp => {
          console.log(this.noticiaslistas);
          console.log(resp);
          this.noticiaslistas = resp.noticiasObtener!;
          return resp.noticiasObtener?.length != 0

        }),
        catchError(err => of(false))
      );
  }

  borrarNoticias(id: number) {
    const url = `${this.baseUrl}/noticias/eliminarNoticia/${id}`;
    return this.http.delete<noticiasCrear>(url)
      .pipe(
        map(resp => {
          return resp.status != null;
        }),
        catchError(err => of(false))
      );
  }

  obtenerNoticiasid(id?: number) {
    const url = `${this.baseUrl}/noticias/obtenerNoticias/${id}`;

    return this.http.get<noticiasListaId>(url)
      .pipe(
        map(resp => {
          console.log(this.noticiaslistaId);
          console.log(resp);
          this.noticiaslistaId = resp.noticiasListaId!;
          return resp.noticiasListaId?.length != 0

        }),
        catchError(err => of(false))
      );
  }

  editarNoticias(titular?: string, cuerpo?: string, id?: number) {
    const url = `${this.baseUrl}/noticias/editar/${id}`;
    const body = {id,titular, cuerpo};

    return this.http.post<noticiasCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }


}
