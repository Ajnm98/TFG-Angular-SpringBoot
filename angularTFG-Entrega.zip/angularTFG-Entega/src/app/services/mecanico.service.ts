import {Injectable} from "@angular/core";
import {vehiculoBorrar, vehiculoCrear, vehiculoUsuario, VehiculoUsuario} from "../interfaces/interfaceVehiculo";
import {environment} from "../../environments/environment";
import {HttpClient} from "@angular/common/http";
import {catchError, map, of} from "rxjs";
import {mecanicoCrear, mecanicolista, mecanicoListaId, mecanicoObtener} from "../interfaces/interfaceMecanico";

@Injectable({
  providedIn: 'root'
})
export class MecanicoService {

  public mecanicolistaId!: mecanicolista;

  public mecanicolistas!: mecanicolista[];



  private baseUrl: string = environment.baseUrl;


  constructor(private http: HttpClient) {
  }

  borrarMecanico(id: number) {
    const url = `${this.baseUrl}/mecanico/eliminarPorId/${id}`;
    return this.http.delete<mecanicoCrear>(url)
      .pipe(
        map(resp => {
          return resp.status != null;
        }),
        catchError(err => of(false))
      );
  }




  obtenerMecanicoid(id?: number) {
    const url = `${this.baseUrl}/mecanico/obtenerMecanico/${id}`;

    return this.http.get(url)
      .pipe(map (resp => {
          // console.log(resp);
          return resp;
        }),
        catchError(error => of(false)))
      ;
  }


  obtenerMecanicos() {
    const url = `${this.baseUrl}/mecanico/obtener`;

    return this.http.get<mecanicoObtener>(url)
      .pipe(
        map(resp => {
          console.log(this.mecanicolistas);
          console.log(resp);
          this.mecanicolistas = resp.mecanicoObtener!;
          return resp.mecanicoObtener?.length != 0

        }),
        catchError(err => of(false))
      );
  }


  crearMecanico(nombre?: string, apellidos?: string, especialidad?: string, identificacion?: string, email?: string, contrasenia?: string) {
    const url = `${this.baseUrl}/mecanico/crear`;
    const body = {nombre, apellidos, especialidad, identificacion, email, contrasenia};

    return this.http.post<mecanicoCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }


  editarMecanico(nombre?: string, apellidos?: string, especialidad?: string, identificacion?: string, id?: number) {
    const url = `${this.baseUrl}/mecanico/editar/${id}`;
    const body = {nombre, apellidos, especialidad, identificacion};

    return this.http.post<mecanicoCrear>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.status != null;
        }),
        catchError(err => of(false))
      )
  }
}
