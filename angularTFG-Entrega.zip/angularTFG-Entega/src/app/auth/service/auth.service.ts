import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {BehaviorSubject, Observable, catchError, map, of, tap, pipe} from 'rxjs';
import { environment } from 'src/environment/environment';
import {listaUsuario, Registro, TokenData, UserData, UserLogged, Usuario} from '../interfaces/interface';
import {vehiculoCrear, VehiculoUsuario, vehiculoUsuario} from "../../interfaces/interfaceVehiculo";
import {citaCrear} from "../../interfaces/inferfaceCitas";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public usuarios!: Usuario[];

  public user!:Usuario;

  private baseUrl: string = environment.baseUrl;

  private userSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  public user$: Observable<any> = this.userSubject.asObservable();

  constructor(private http: HttpClient) { }

  setUser(user: any) {
    this.userSubject.next(user);
  }



  updateContrasenia(email?: string, password?: string) {
    const url = `${this.baseUrl}/usuario/updateContrasnia`;
    const body = {email, password};

    return this.http.post<Registro>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.message != null;
        }),
        catchError(err => of(false))
      )
  }

  mandarCorreo(email?: string,) {
    const url = `${this.baseUrl}/usuario/mandarcorreo`;
    const body = {email};

    return this.http.post<Registro>(url, body)
      .pipe(
        map(resp => {
          console.log(resp);
          return resp.message != null;
        }),
        catchError(err => of(false))
      )
  }

  registro(username:string, email: string, password:string): Observable<boolean>{
    const url = `${this.baseUrl}/api/auth/signup`;
    const roles: string[] = ['ROLE_USER','ROLE_ADMIN'];
    const body = {username, email, password, roles};

    return this.http.post<Registro>(url,body)
      .pipe(
        map(res => {
          console.log(res.message);
          return res.message!=null
        }),
        catchError(err => of(false))
      )
  }

  obtenerUsuario() {
    const url = `${this.baseUrl}/usuario/obtenerTodos`;

    return this.http.get<listaUsuario>(url)
      .pipe(
        map(resp => {
          console.log(this.usuarios);
          console.log(resp);
          this.usuarios = resp.usuarioObtener!;
          return resp.usuarioObtener?.length != 0

        }),
        catchError(err => of(false))
      );
  }


  login(username: string, password:string){

    const url = `${this.baseUrl}/api/auth/signin`;
    const body = {username, password};

    return this.http.post<TokenData>(url, body)
      .pipe(
        tap( resp => {
          if (resp.token){
            localStorage.setItem('token', resp.token);
          }
        }),
        map(resp => resp.token),
        catchError(err => of(false))
      )
  }


  validarToken(): Observable<boolean>{
    const url = `${this.baseUrl}/api/auth/userLogged`;
    const headers = new HttpHeaders()
      .set('Authorization', 'Bearer ' + localStorage.getItem('token') || '');

    return this.http.get<UserLogged>(url, {headers})
      .pipe(
        map(resp => {
           this.user = {
             id:resp.id,
            username: resp.username,
            roles: resp.roles,
            email: resp.email,
            provider: null
          };
          console.log("ok");
          return resp.username!=null;
        }),
        catchError(err => {
          console.log('Error:', err);
          return of(false);
        })

      )
  }

}
