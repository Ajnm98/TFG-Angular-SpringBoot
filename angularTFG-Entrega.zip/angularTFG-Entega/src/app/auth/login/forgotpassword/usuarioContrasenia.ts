export class usuarioContrasenia {
  constructor(
    public email: string,

  ){}
}
