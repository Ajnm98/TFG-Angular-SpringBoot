import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {VehiculoService} from "../../../services/vehiculo.service";
import {AuthService} from "../../service/auth.service";
import {usuarioContrasenia} from "./usuarioContrasenia";

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit{

  get obtenerUsuario(){
    return this.authService.usuarios;
  }

  usuarioComprobacion = new usuarioContrasenia("");
  existe = 0;

  constructor(private route: ActivatedRoute,
              private router: Router, private authService: AuthService) {
  }

  listarUsuario(){
    this.authService.obtenerUsuario()
      .subscribe(resp =>{
        console.log(this.obtenerUsuario);
      })
  }
  ngOnInit(): void {
    this.listarUsuario();
  }

  correo(){
    for(var usuario of this.obtenerUsuario){
      if(usuario.email == this.usuarioComprobacion.email){
        this.existe = 1;
        this.authService.mandarCorreo(this.usuarioComprobacion.email)
          .subscribe(resp => {
            if(resp){
              console.log('sipe ')
              //ejecutamos onInit para refrescar la página y aparezca el mensaje.
              this.ngOnInit();
            }else{
              console.log('nope')
            }
          })

        break;
      }
      this.existe = 2;
    }
  }

}
