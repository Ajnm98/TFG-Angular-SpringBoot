export class cambiarContrasenia {
  constructor(
    public password: string,

  ){}
}
