import { Component } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {AuthService} from "../../../service/auth.service";
import {usuarioContrasenia} from "../usuarioContrasenia";
import {cambiarContrasenia} from "./cambiarContrasenia";

@Component({
  selector: 'app-cambiarcontrasenia',
  templateUrl: './cambiarcontrasenia.component.html',
  styleUrls: ['./cambiarcontrasenia.component.css']
})
export class CambiarcontraseniaComponent {

  constructor(private route: ActivatedRoute,
              private router: Router, private authService: AuthService) {
  }
  existe = 1;
  cambiarContrasenia1 = new cambiarContrasenia("");

  ngOnInit(): void {
  }

  contrasenia() {
    const email = this.route.snapshot.paramMap.get('email');
    this.authService.updateContrasenia(email,this.cambiarContrasenia1.password)
      .subscribe(resp => {
        this.existe = 0;
        this.ngOnInit();
      })
  }
}
