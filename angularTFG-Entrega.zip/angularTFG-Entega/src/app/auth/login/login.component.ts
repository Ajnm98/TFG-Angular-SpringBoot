import { Router } from '@angular/router';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

    //importar ReactiveFormsModule en el módulo.
    miFormulario: FormGroup = this.fb.group({
      username: ['', [ Validators.required, Validators.minLength(4) ]],
      email: ['', [ Validators.required, Validators.email ]],
      password: ['', [ Validators.required, Validators.minLength(4) ]]
    });

  constructor(private router: Router, private fb: FormBuilder,
              private authService: AuthService){}

  login(){
    const { username, password } = this.miFormulario.value;

    this.authService.login(username,password)
      .subscribe(resp => {
        if(resp){
          console.log(resp);
          this.router.navigateByUrl('/dashboard/menu');
        }else{
          console.log(resp)
        }
      });
  }


}
