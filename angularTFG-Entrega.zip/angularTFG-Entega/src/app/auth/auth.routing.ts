import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ForgotpasswordComponent} from "./login/forgotpassword/forgotpassword.component";
import {CambiarcontraseniaComponent} from "./login/forgotpassword/cambiarcontrasenia/cambiarcontrasenia.component";


const routes: Routes = [
    {
      path:'',
      children:[
        {path:'login', component:LoginComponent},
        {path:'register', component:RegisterComponent},
        { path: 'forgotpassword', component: ForgotpasswordComponent },
        { path: 'usuariocontraseña/:email', component: CambiarcontraseniaComponent },
        { path: '**', redirectTo:'login' },
      ]
    }


];


@NgModule({
  declarations: [],
  imports: [ RouterModule.forChild(routes) ],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
