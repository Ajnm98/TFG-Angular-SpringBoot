export interface UserData {
    ok: boolean;
    usuarios: Usuario[];
  }

  export interface Usuario {
    id?: number;
    username: string;
    email: string;
    password?: string;
    roles: RolesI[];
    provider: string | null;
  }


  export interface TokenData {
    token: string;
    type: string;
    id: number;
    username: string;
    email: string;
    roles: string[];
  }

  export interface Registro {
    message: string;
  }

  export interface UserLogged {
    roles: RolesI[];
    id: number;
    email: string;
    username: string;
  }


  export interface RolesI{
    id?: number;
    name?: string;
  }

export interface listaUsuario {
  ok: boolean;
  usuarioObtener: Usuario[];
}
