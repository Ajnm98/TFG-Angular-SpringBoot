import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

      //importar ReactiveFormsModule en el módulo.
      miFormulario: FormGroup = this.fb.group({
        username: ['', [ Validators.required, Validators.minLength(4) ]],
        email: ['', [ Validators.required, Validators.email ]],
        password: ['', [ Validators.required, Validators.minLength(4) ]]
      });

    constructor(private router: Router, private fb: FormBuilder,
                private authService: AuthService, private route: ActivatedRoute){}



    registro(){
    const {username, email, password } = this.miFormulario.value;


    this.authService.registro(username, email,password)
      .subscribe(resp => {
        if(resp){
          console.log(resp);
          this.router.navigateByUrl("/auth/login");
        }else{
          console.log(resp);
        }
      });
  }
}
