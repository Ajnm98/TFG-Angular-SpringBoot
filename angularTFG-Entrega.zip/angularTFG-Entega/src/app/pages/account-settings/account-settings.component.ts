import { AuthService } from 'src/app/auth/service/auth.service';
import { SettingsService } from './../../services/settings.service';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { DatosUsuario } from '../datos-usuario/datosUsuario';
import { Usuario } from 'src/app/auth/interfaces/interface';
import { DatosUsuarioService } from 'src/app/services/datosUsuario.service';

@Component({
  selector: 'app-account-settings',
  templateUrl: './account-settings.component.html',
  styles: [
  ]
})
export class AccountSettingsComponent implements OnInit, OnDestroy{

  constructor(private settingsService: SettingsService, private auth: AuthService, 
    private datosUsuario: DatosUsuarioService){}

  usuarioAuth : Usuario
  usuario : DatosUsuario = new DatosUsuario('','', '', '','');
  datoUsuarioInterface : DatosUsuario



  ngOnInit(): void {
    this.settingsService.checkCurrentTheme();
    const usuarioId = this.auth.user.id; // ID del usuario que deseas obtener
    this.usuarioAuth = this.auth.user;
    this.datosUsuario.getDatosUsuario(usuarioId).subscribe(
      (usuario: DatosUsuario) => {
        this.usuario = usuario;
        // Aquí puedes realizar otras operaciones con el usuario
      },
      error => {
        console.error(error);
        // Manejo de errores
      }
    );
  }

  ngOnDestroy(): void {
    
  }

  changeTheme(theme: string){
    this.settingsService.changeTheme(theme);

  }

  onSubmit() {
    this.datosUsuario.updateDatosUsuario(
      this.usuario.nombre,
      this.usuario.apellidos,
      this.usuario.dni,
      this.usuario.direccion,
      this.usuario.telefono,
      this.auth.user.id
    ).subscribe(
      (response: DatosUsuario) => {
        this.mensajeAlert()
        // Aquí puedes realizar acciones después de la actualización exitosa
        console.log('Actualización exitosa', response);
        this.ngOnInit()
      },
      (error: any) => {
        // Aquí puedes manejar errores de actualización
        console.error('Error en la actualización', error);
      }
    );
  }

  mensajeAlert(){
    const alert = document.querySelector("#alert")
    alert.classList.remove('hidden')
    setTimeout(()=> {
      alert.classList.add('hidden')
    },3000)
  }


}
