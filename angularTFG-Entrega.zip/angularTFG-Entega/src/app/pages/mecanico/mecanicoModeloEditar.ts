export class MecanicoModeloEditar {

  constructor(
    public nombre: string,
    public apellidos: string,
    public especialidad: string,
    public identificacion: string,

  ) {
  }
}
