import { Component, OnInit } from '@angular/core';
import {Vehiculomodelo} from "../../vehiculo/vehiculomodelo";
import {FormBuilder} from "@angular/forms";
import {VehiculoService} from "../../../services/vehiculo.service";
import {AuthService} from "../../../auth/service/auth.service";
import {Mecanicomodelo} from "../../citas/mecanicomodelo";
import {MecanicoService} from "../../../services/mecanico.service";
import {Mecanicomodelocrear} from "../mecanicoModelocrear";
import { Router } from '@angular/router';

@Component({
  selector: 'app-mecanico',
  templateUrl: './mecanico.component.html',
  styleUrls: ['./mecanico.component.css']
})
export class MecanicoComponent implements OnInit{



  constructor(private fb: FormBuilder,
              private mecanicoService: MecanicoService, private authService: AuthService, private router: Router) {
  }

  ngOnInit(): void {

  }


  mecanico = new Mecanicomodelocrear("","", "", "", "", "");



  crearMecanico(){
    const { nombre, apellidos,especialidad, identificacion, email, contrasenia} = this.mecanico;


    this.mecanicoService.crearMecanico(nombre, apellidos,  especialidad, identificacion, email, contrasenia)
      .subscribe(resp => {
        if(resp){

          this.router.navigateByUrl('/dashboard/mecanico/mostrar')
          this.mensajeAlert()
          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          this.ngOnInit();
        }else{

        }
      })
  }



  mensajeAlert(){
    const alert = document.querySelector("#alert")
    alert.classList.remove('hidden')
    setTimeout(()=> {
      alert.classList.add('hidden')
    },3000)
  }
}
