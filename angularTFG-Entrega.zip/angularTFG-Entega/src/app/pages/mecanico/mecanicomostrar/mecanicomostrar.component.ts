import {Component, OnInit} from '@angular/core';
import {FormBuilder} from "@angular/forms";
import {MecanicoService} from "../../../services/mecanico.service";
import {AuthService} from "../../../auth/service/auth.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-mecanicomostrar',
  templateUrl: './mecanicomostrar.component.html',
  styleUrls: ['./mecanicomostrar.component.css']
})
export class MecanicomostrarComponent implements OnInit{


  constructor(private fb: FormBuilder,
              private mecanicoService: MecanicoService, private authService: AuthService, private router: Router) {
  }

  get obtenerMecanicos(){
    return this.mecanicoService.mecanicolistas;
  }

  obtenerCantidadMecanicos(): number{
    let listaMecanicos = this.listarMecanicos
    return listaMecanicos.length
  }

  public quantityMecanicos: number;

  ngOnInit() {
    this.listarMecanicos();
    this.obtenerCantidadMecanicos()

  }

  borrarMecanico(id: number) {
    this.mecanicoService.borrarMecanico(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }

  listarMecanicos(){
    // const usermail = this.authService.usuario.username!;
    console.log(this.obtenerMecanicos);
    this.mecanicoService.obtenerMecanicos()
      .subscribe(resp =>{
        if(resp){
          this.quantityMecanicos = this.mecanicoService.mecanicolistas.length;
        }
      })
  }

  onEditProfile(id: number) {
    this.router.navigateByUrl('dashboard/mecanico/editar/' +id)
  }





}
