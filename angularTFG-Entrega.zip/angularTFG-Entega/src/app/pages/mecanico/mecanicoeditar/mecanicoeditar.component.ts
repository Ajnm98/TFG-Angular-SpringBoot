import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {VehiculoService} from "../../../services/vehiculo.service";
import {MecanicoService} from "../../../services/mecanico.service";
import {Vehiculomodelo} from "../../vehiculo/vehiculomodelo";
import {Mecanicomodelocrear} from "../mecanicoModelocrear";
import {DatosUsuario} from "../../datos-usuario/datosUsuario";
import {MecanicoModeloEditar} from "../mecanicoModeloEditar";

@Component({
  selector: 'app-mecanicoeditar',
  templateUrl: './mecanicoeditar.component.html',
  styleUrls: ['./mecanicoeditar.component.css']
})
export class MecanicoeditarComponent {


  constructor(private route: ActivatedRoute,
              private router: Router,
              private mecanicoService: MecanicoService) {

  }


  mecanicoeditar: MecanicoModeloEditar = new MecanicoModeloEditar('', '', '', '');
  datosMecanico: MecanicoModeloEditar


  editarMecanico() {

    const id = Number(this.route.snapshot.paramMap.get('id'));

    this.mecanicoService.editarMecanico(
      this.mecanicoeditar.nombre,
      this.mecanicoeditar.apellidos,
      this.mecanicoeditar.especialidad,
      this.mecanicoeditar.identificacion, id)
      .subscribe(resp => {
        if (resp) {
          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          this.ngOnInit();
        } else {

          this.mensajeAlert()
          setTimeout( () =>{
          },3000)

        }
      })
  }


  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.mecanicoService.obtenerMecanicoid(id).subscribe(resp => {
        this.mecanicoeditar.nombre = resp['mecanicoeditar'][0]['nombre'];
        this.mecanicoeditar.apellidos = resp['mecanicoeditar'][0]['apellidos'];
        this.mecanicoeditar.especialidad = resp['mecanicoeditar'][0]['especialidad'];
        this.mecanicoeditar.identificacion = resp['mecanicoeditar'][0]['identificacion'];
      },
      error => {
        console.error(error);
        // Manejo de errores
      })
  }

  mensajeAlert(){
    const alert = document.querySelector("#alert")
    alert.classList.remove('hidden')
    setTimeout(()=> {
      alert.classList.add('hidden')
    },3000)
  }

}





