import { AccountSettingsComponent } from './account-settings/account-settings.component';
import { Grafica1Component } from './grafica1/grafica1.component';
// import { ProgressComponent } from './progress/progress.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PagesComponent } from './pages.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReparacionesEstandarComponent } from './reparaciones-estandar/reparaciones-estandar.component';
import {CitasComponent} from "./citas/citas.component";
import {CitausuarioComponent} from "./citas/citausuario/citausuario.component";
import {VehiculoComponent} from "./vehiculo/vehiculocrear/vehiculo.component";
import {VehiculomostrarComponent} from "./vehiculo/vehiculomostrar/vehiculomostrar.component";
import {VehiculoeditarComponent} from "./vehiculo/vehiculoeditar/vehiculoeditar.component";
import {NopagefoundComponent} from "../nopagefound/nopagefound.component";
import {ProgressComponent} from "./progress/progress.component";
import {LoginComponent} from "../auth/login/login.component";
import {RegisterComponent} from "../auth/register/register.component";
import {MecanicoComponent} from "./mecanico/mecanicocrear/mecanico.component";
import {MecanicomostrarComponent} from "./mecanico/mecanicomostrar/mecanicomostrar.component";
import {MecanicoeditarComponent} from "./mecanico/mecanicoeditar/mecanicoeditar.component";
import { DatosUsuarioComponent } from './datos-usuario/datos-usuario.component';
import { PerfilUsuarioComponent } from './perfil-usuario/perfil-usuario.component';
import {NoticiascrearComponent} from "./noticias/noticiascrear/noticiascrear.component";
import {NoticiasmostrarComponent} from "./noticias/noticiasmostrar/noticiasmostrar.component";
import {NoticiaseditarComponent} from "./noticias/noticiaseditar/noticiaseditar.component";
import {UsuariomostrarComponent} from "./usuario/usuariomostrar/usuariomostrar.component";
import {UsuarioeditarComponent} from "./usuario/usuarioeditar/usuarioeditar.component";
import {NoticiasverComponent} from "./noticias/noticiasver/noticiasver.component";
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FaqComponent } from './faq/faq.component';
import {ListarusuarioComponent} from "./citas/listarusuario/listarusuario.component";
import {PagarahoraComponent} from "./pagar/pagarahora/pagarahora.component";


const routes: Routes = [
    {
        path: '',
        component: PagesComponent,
        children: [
          {path:'dashboard', component:DashboardComponent, data:{ titulo: 'Dashboard' }},
          {path:'progress', component:ProgressComponent, data:{ titulo: 'ProgressBar' }},
          {path:'grafica1', component:Grafica1Component, data:{ titulo: 'Gráfica' }},
          {path:'account-settings', component:AccountSettingsComponent, data:{ titulo: 'Ajustes de Cuenta' }},
          {path:'reparaciones-estandar', component:ReparacionesEstandarComponent, data:{ titulo: 'Ajustes de Reparaciones' }},
          {path:'completar-registro', component: DatosUsuarioComponent},
          {path:'perfil', component: PerfilUsuarioComponent},
          {path:'citasmecanico', component: CitasComponent},
          {path:'citasusuario', component: CitausuarioComponent},
          {path:'vehiculo', component: VehiculoComponent},
          {path:'mecanico/crear', component: MecanicoComponent},
          {path:'mecanico/mostrar', component: MecanicomostrarComponent},
          {path:'mecanico/editar/:id', component: MecanicoeditarComponent},
          {path:'noticias/editar/:id', component: NoticiaseditarComponent},
          {path:'vehiculo/editar/:id', component:VehiculoeditarComponent},
          {path:'vehiculousuario', component:VehiculomostrarComponent},
          {path:'listarcitausuario', component:ListarusuarioComponent},
          {path:'pagar/:id', component: PagarahoraComponent},
          {path:'noticiacrear', component:NoticiascrearComponent},
          {path:'menu', component:NoticiasmostrarComponent},
          {path:'usuario/mostrar', component: UsuariomostrarComponent},
          {path:'usuario/editar/:id', component: UsuarioeditarComponent},
          {path:'noticias/ver/:id', component: NoticiasverComponent},
          {path:'contacto', component: ContactUsComponent},
          {path:'faq', component: FaqComponent},

          {path:'', redirectTo: '/dashboard', pathMatch: 'full'},
          {path:'**', redirectTo:'auth/login'},
          {path: '**', redirectTo:'dashboard'}
        ]
    },
];


@NgModule({
  declarations: [],
  imports: [ RouterModule.forChild(routes) ],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
