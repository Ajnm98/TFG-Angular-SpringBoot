import { Component } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {VehiculoService} from "../../../services/vehiculo.service";
import {Observable} from "rxjs";
import {Vehiculomodelo} from "../vehiculomodelo";
import {AuthService} from "../../../auth/service/auth.service";
import {MecanicoModeloEditar} from "../../mecanico/mecanicoModeloEditar";

@Component({
  selector: 'app-vehiculoeditar',
  templateUrl: './vehiculoeditar.component.html',
  styleUrls: ['./vehiculoeditar.component.css']
})
export class VehiculoeditarComponent {

  constructor(private route: ActivatedRoute,
              private router: Router,
              private vehiculoService: VehiculoService, private authService: AuthService) {

  }

  vehiculoeditar: Vehiculomodelo = new Vehiculomodelo("","",new Date(),"","");



  editarVehiculo(){
    const id = Number(this.route.snapshot.paramMap.get('id'));

    console.log(this.vehiculoeditar);

    this.vehiculoService.editarVehiculo(
      this.vehiculoeditar.tipoVehiculo,
      this.vehiculoeditar.modeloVehiculo,
      this.vehiculoeditar.fecha_creacion,
      this.vehiculoeditar.tipoCombustible,
      this.vehiculoeditar.matricula, id)
      .subscribe(resp => {
        if(resp){

          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          this.ngOnInit();
        }else{
          this.mensajeAlert()
          setTimeout( () =>{

          },3000)
        }
      })
  }

  private ngOnInit() {
    // const usermail = this.authService.usuario.username!;
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.vehiculoService.obtenerVehiculoid(id)
      .subscribe(resp =>{
        console.log(resp);
        this.vehiculoeditar.tipoCombustible = resp['vehiculoUsuariolista'][0]['tipoCombustible'];
        this.vehiculoeditar.modeloVehiculo = resp['vehiculoUsuariolista'][0]['modeloVehiculo'];
        this.vehiculoeditar.fecha_creacion = resp['vehiculoUsuariolista'][0]['fecha_creacion'];
        this.vehiculoeditar.matricula = resp['vehiculoUsuariolista'][0]['matricula'];
        this.vehiculoeditar.tipoVehiculo = resp['vehiculoUsuariolista'][0]['tipoVehiculo'];

      })
  }

  mensajeAlert(){
    const alert = document.querySelector("#alert")
    alert.classList.remove('hidden')
  }

}
