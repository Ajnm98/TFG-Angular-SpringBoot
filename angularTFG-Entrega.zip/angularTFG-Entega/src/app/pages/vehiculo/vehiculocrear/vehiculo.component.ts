import { AuthService } from './../../../auth/service/auth.service';
import {Component, NgModule, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {VehiculoService} from "../../../services/vehiculo.service";
import { ReactiveFormsModule } from '@angular/forms';
import {Vehiculomodelo} from "../vehiculomodelo";
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-vehiculo',
  templateUrl: './vehiculo.component.html',
  styleUrls: ['./vehiculo.component.css']
})
export class VehiculoComponent implements OnInit{
  public someValue:string= '';

  constructor(private fb: FormBuilder,
              private vehiculoService: VehiculoService,
              private toastr: ToastrService, private authService: AuthService, private router: Router) {
  }

  vehiculo = new Vehiculomodelo("","",new Date(),"","");

  ngOnInit(): void {

  }

  crearVehiculousuario(){
    const { tipoVehiculo, modeloVehiculo, fecha_creacion, tipoCombustible, matricula } = this.vehiculo;
    const id = this.authService.user.id!;

    console.log(this.vehiculo);

    this.vehiculoService.crearVehiculo(tipoVehiculo, modeloVehiculo, fecha_creacion,  tipoCombustible, matricula, id)
      .subscribe(resp => {
        if(!resp){
          this.mensajeAlert()
          // this.toastr.success('El vehiculo se ha creado correctamente')
          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          setTimeout(()=> {
          this.router.navigateByUrl('/dashboard/vehiculousuario');
          }, 3000)
          this.ngOnInit();
        }else{

        }
      })
  }

  mensajeAlert(){
    const alert = document.querySelector("#alert")
    alert.classList.remove('hidden')
    setTimeout(()=> {
      alert.classList.add('hidden')
    },3000)
  }


}
