
export class Vehiculomodelo {
  public someValue: string = '';

  constructor(
    public tipoVehiculo: string,
    public modeloVehiculo: string,
    public fecha_creacion: Date,
    public tipoCombustible: string,
    public matricula: string) {
  }
}
