import { Component } from '@angular/core';
import {VehiculoService} from "../../../services/vehiculo.service";
import {ActivatedRoute, Router} from "@angular/router";
import {AuthService} from "../../../auth/service/auth.service";
import { VehiculoUsuario } from 'src/app/interfaces/interfaceVehiculo';

@Component({
  selector: 'app-vehiculomostrar',
  templateUrl: './vehiculomostrar.component.html',
  styleUrls: ['./vehiculomostrar.component.css']
})

export class VehiculomostrarComponent {

  get obtenerVehiculoUsuarios(){
    return this.vehiculoService.vehiculoUsuarios;
  }

  constructor(private route: ActivatedRoute,
              private router: Router,
              private vehiculoService: VehiculoService, private authService: AuthService) {
  }

  borrarVehiculo(id: number) {
    this.vehiculoService.borrarVehiculo(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }


  listarVehiculo(){
    const usermail = this.authService.user.id!;
    this.vehiculoService.obtenerVehiculo(usermail)
      .subscribe(resp =>{
        console.log(this.obtenerVehiculoUsuarios);
      })
  }
  private ngOnInit() {
    this.listarVehiculo();
  }

  onEditProfile(id: number) {
    this.router.navigateByUrl('dashboard/vehiculo/editar/' +id)
  }



}
