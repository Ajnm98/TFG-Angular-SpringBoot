import { Component, OnInit } from '@angular/core';
import { Usuario } from './../../auth/interfaces/interface';

import { AuthService } from 'src/app/auth/service/auth.service';
import { DatosUsuario } from 'src/app/pages/datos-usuario/datosUsuario';
import { DatosUsuarioService } from 'src/app/services/datosUsuario.service';

@Component({
  selector: 'app-perfil-usuario',
  templateUrl: './perfil-usuario.component.html',
  styleUrls: ['./perfil-usuario.component.css']
})
export class PerfilUsuarioComponent implements OnInit{

  constructor(private auth: AuthService,private datosUsuario: DatosUsuarioService) {
    
  }

  usuarioAuth : Usuario
  usuario : DatosUsuario = new DatosUsuario('','', '', '','');

  ngOnInit(): void {
    const usuarioId = this.auth.user.id; // ID del usuario que deseas obtener
    this.usuarioAuth = this.auth.user;

    this.datosUsuario.getDatosUsuario(usuarioId).subscribe(
      (usuario: DatosUsuario) => {
        this.usuario.nombre = usuario.nombre;
        this.usuario.apellidos = usuario.apellidos;
        this.usuario.telefono = usuario.telefono;
        this.usuario.direccion = usuario.direccion;
        this.usuario.dni = usuario.dni;
        // Aquí puedes realizar otras operaciones con el usuario
      },
      error => {
        console.error(error);
        // Manejo de errores
      }
    );
  }

}
