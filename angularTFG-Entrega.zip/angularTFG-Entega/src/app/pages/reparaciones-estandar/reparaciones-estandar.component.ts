import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ReparacionesService } from 'src/app/services/reparaciones.service';

import { ToastrService } from "ngx-toastr";
import { EstandarReparacion } from 'src/app/interfaces/reparacionesI';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-reparaciones-estandar',
  templateUrl: './reparaciones-estandar.component.html',
  styles: [`
    .scrollable-table {
      max-height: 400px; /* Altura máxima deseada para la tabla */
      overflow-y: auto;
    }
  `]
})
export class ReparacionesEstandarComponent {


  estandarSeleccionado: EstandarReparacion | null;
  mostrarFormularioCrear: boolean = true;
  formularioDesplegable = false;


//importar ReactiveFormsModule en el módulo.
miFormulario: FormGroup = this.fb.group({
  nombre: ['', [ Validators.required, Validators.minLength(4) ]],
  descripcion: ['', [ Validators.required ]],
  precio_estimado: ['', [ Validators.required ]],
  duracion_estimada: ['', [ Validators.required ]]
});

nuevoEstandarForm: FormGroup = this.fb.group({
  nombre: ['', [ Validators.required, Validators.minLength(4) ]],
  descripcion: ['', [ Validators.required ]],
  precio_estimado: ['', [ Validators.required ]],
  duracion_estimada: ['', [ Validators.required ]]
});


constructor(private router: Router, private fb: FormBuilder,
  private reparacionesService: ReparacionesService,
  private toastr: ToastrService){}

  ngOnInit(): void {
    this.obtenerTodosLosEstandares();
  }

  get obtenerEstandares(){
    return this.reparacionesService.listaEstandar;
  }

  toggleFormulario() {
    this.formularioDesplegable = !this.formularioDesplegable;
  }

  crearEstandar(){

    const {nombre, descripcion, precio_estimado, duracion_estimada} = this.miFormulario.value;


    this.reparacionesService.crearEstandar(nombre, descripcion, precio_estimado, duracion_estimada)
      .subscribe(resp => {
        if(resp){
          console.log(resp);
          this.toastr.success(`El servicio ${nombre} se ha creado correctamente`, 'Éxito');
          this.router.navigateByUrl('/dashboard/reparaciones-estandar');
        }else{
          this.toastr.error('Ha ocurrido un error al crear el servicio', 'Error');
          console.log(resp);
          console.log(this.miFormulario.value);
        }
      });
  }



  obtenerTodosLosEstandares(){

    this.reparacionesService.listarEstandares()
      .subscribe(resp => {
        if(resp){
          console.log(resp);
        }else{
          console.log(resp);
        }
      });
  }


  editarEstandar(estandar: any) {
    // Asignar los valores del estandar seleccionado al formulario de edición
    this.nuevoEstandarForm.patchValue({
      nombre: estandar.nombre,
      descripcion: estandar.descripcion,
      precio_estimado: estandar.precio_estimado,
      duracion_estimada: estandar.duracion_estimada
    });
    this.estandarSeleccionado = estandar;
    this.mostrarFormularioCrear = false;
  }


  guardarCambios(estandarId:number) {

    const {nombre, descripcion, precio_estimado, duracion_estimada} = this.nuevoEstandarForm.value;

    this.reparacionesService.actualizarEstandar(estandarId!,nombre,descripcion,precio_estimado,duracion_estimada)
      .subscribe(resp => {
        // Manejar la respuesta del servicio, mostrar notificaciones, etc.
        this.toastr.success('Los cambios se han guardado correctamente', 'Éxito');
        window.location.reload();
      });
    this.estandarSeleccionado = null; // Limpiar el estandarSeleccionado después de guardar los cambios
  }

  cancelarEdicion() {
    this.estandarSeleccionado = null; // Limpiar el estandarSeleccionado al cancelar la edición
    this.mostrarFormularioCrear = true;
  }


  eliminarEstandar(estandarId:number){

    Swal.fire({
      title: '¿Seguro que quieres eliminar este servicio?',
      text: "No podrás revertir los cambios",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: '¡Sí, eliminar!'
    }).then((result) => {
      if (result.isConfirmed) {

        this.reparacionesService.eliminarEstandar(estandarId)
      .subscribe(resp => {
        this.toastr.success('Se ha eliminado correctamente', 'Éxito');
      })

        Swal.fire(
          '¡Eliminado!',
          'El servicio ha sido eliminado.',
          'success'
        )

        window.location.reload();
      }
    })

  }

}
