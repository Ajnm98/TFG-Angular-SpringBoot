import {Component, ChangeDetectorRef, OnInit} from '@angular/core';
import {CalendarOptions, DateSelectArg, EventClickArg, EventApi, EventInput} from '@fullcalendar/core';
import interactionPlugin from '@fullcalendar/interaction';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
// import { INITIAL_EVENTS, createEventId } from './event.citas';
import {FormBuilder} from "@angular/forms";
import {VehiculoService} from "../../services/vehiculo.service";
import {CitaService} from "../../services/citas.service";
import {Vehiculomodelo} from "../vehiculo/vehiculomodelo";
import {Citamodelo} from "./citamodelo";
import {VehiculoUsuario} from "../../interfaces/interfaceVehiculo";
import {citasObtener} from "../../interfaces/inferfaceCitas";
import {createEventId, INITIAL_EVENTS} from "./event.citas";
import * as events from "events";
import {environment} from "../../../environments/environment";
import {AuthService} from "../../auth/service/auth.service";
import _default from "chart.js/dist/plugins/plugin.tooltip";
import numbers = _default.defaults.animations.numbers;




@Component({
  selector: 'citas-root',
  templateUrl: './citas.component.html',
  styleUrls: ['./citas.component.css']
})
export class CitasComponent{
  private baseUrl: string = environment.baseUrl;
  private idmecanico = Number(this.authService.user.id); // Cambiar por const mecanico.
  ngOnInit() {
    // this.eventos.push(this.obtenerCitas);
    console.log(this.authService.user.roles);


  }


  descripcion = "";
  calendarVisible = true;
  // @ts-ignore
  // @ts-ignore
  calendarOptions: CalendarOptions = {
    plugins: [
      interactionPlugin,
      dayGridPlugin,
      timeGridPlugin,
      listPlugin,
    ],
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
    },
    initialView: 'timeGridWeek',
    // initialEvents: this.eventos, // alternatively, use the `events` setting to fetch from a feed
    weekends: false,
    editable: true,
    selectable: true,
    selectMirror: true,
    dayMaxEvents: true,
    // select: this.handleDateSelect.bind(this),
    eventClick: this.handleEventClick.bind(this),
    eventsSet: this.handleEvents.bind(this),
    // /* you can update a remote database when these fire:
    // eventAdd:
     events: `${this.baseUrl}/cita/obtener/${this.idmecanico}`,

    // eventChange:
    // eventRemove:
    // */
  };
  currentEvents: EventApi[] = [];

  constructor(private changeDetector: ChangeDetectorRef, private citaService: CitaService, private authService: AuthService) {
  }

  handleCalendarToggle() {
    this.calendarVisible = !this.calendarVisible;
  }

  handleWeekendsToggle() {
    const { calendarOptions } = this;
    calendarOptions.weekends = !calendarOptions.weekends;
  }

 // //Crear cita.
 //  handleDateSelect(selectInfo: DateSelectArg) {
 //    const title = prompt('Por favor escriba su cita');
 //    const calendarApi = selectInfo.view.calendar;
 //    calendarApi.unselect(); // clear date selection
 //    if (title) {
 //      calendarApi.addEvent({
 //        id: createEventId(),
 //        title,
 //        start: selectInfo.startStr,
 //        end: selectInfo.endStr,
 //        allDay: selectInfo.allDay
 //
 //      });
 //      this.cita.descripcion = title;
 //      this.cita.fecha_inicio = selectInfo.start;
 //      this.cita.fecha_fin = selectInfo.end;
 //    }
 //    this.crearCita();
 //  }

  handleEventClick(clickInfo: EventClickArg) {
    if (confirm(`¿Estás seguro que quieres borrar, ${clickInfo.event.display}?`)) {
      clickInfo.event.remove();
      this.borrarCitas(clickInfo.event.id );
    }
  }

  handleEvents(events: EventApi[]) {
    this.currentEvents = events;
    this.changeDetector.detectChanges();
  }

  // cita = new Citamodelo(this.descripcion,new Date(),new Date());

  // crearCita(){
  //   const { descripcion, fecha_inicio, fecha_fin } = this.cita;
  //   // const id_mecanico = this.idmecanico;
  //    const usermail = this.authService.user.id;
  //
  //   console.log(this.cita);
  //
  //   this.citaService.crearCita(descripcion, fecha_inicio, fecha_fin)
  //     .subscribe(resp => {
  //       if(resp){
  //         //ejecutamos onInit para refrescar la página y aparezca el mensaje.
  //         // this.ngOnInit();
  //       }else{
  //
  //       }
  //     })
  // }

  get obtenerCitas(){
    return this.citaService.CitasObtener;
  }


  listarCita(){
    // const usermail = this.authService.usuario.username!;
    this.citaService.obtenerCitas()
      .subscribe(resp =>{
        console.log(this.obtenerCitas);
      })
  }

  borrarCitas(id: string) {
    this.citaService.borrarcita(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }

}
