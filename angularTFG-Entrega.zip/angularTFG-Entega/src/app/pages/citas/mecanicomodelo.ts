
export class Mecanicomodelo {

  constructor(
    public id: number,
    public usuario_id: number,
    public nombre: string,
  ){

  }
}
