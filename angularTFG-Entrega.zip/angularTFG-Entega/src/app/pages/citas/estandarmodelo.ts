export class Estandarmodelo {
  public someValue: string = '';

  constructor(
    public id: number,
    public duracion_estimada: Date){
  }
}
