import {Component, ChangeDetectorRef, OnInit, OnDestroy, Input, TemplateRef, ViewChild} from '@angular/core';
import {CalendarOptions, DateSelectArg, EventClickArg, EventApi, EventInput} from '@fullcalendar/core';
import interactionPlugin from '@fullcalendar/interaction';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
// import { INITIAL_EVENTS, createEventId } from './event.citas';
import {FormBuilder} from "@angular/forms";
import {environment} from "../../../../environments/environment";
import {CitaService} from "../../../services/citas.service";
import {createEventId} from "../event.citas";
import {Citamodelo} from "../citamodelo";
import {MecanicoService} from "../../../services/mecanico.service";
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {Vehiculomodelo} from "../../vehiculo/vehiculomodelo";
import {Mecanicomodelo} from "../mecanicomodelo";
import {AuthService} from "../../../auth/service/auth.service";
import {CalendarView} from "@angular/material/datepicker/testing";
import {ReparacionesService} from "../../../services/reparaciones.service";
import {Estandarmodelo} from "../estandarmodelo";
import {AnimationDurations} from "@angular/material/core";
import {ICreateOrderRequest} from "ngx-paypal";
import _default from "chart.js/dist/plugins/plugin.title";
import start = _default.start;
import {elementAt} from "rxjs";
import {BsModalRef, BsModalService, ModalModule} from 'ngx-bootstrap/modal';
// @ts-ignore
import {Template} from "@angular/compiler";
import {initialState} from "ngx-bootstrap/timepicker/reducer/timepicker.reducer";
import {ToastrService} from "ngx-toastr";
import Swal from "sweetalert2";


@Component({
  selector: 'citas-root',
  templateUrl: './citausuario.component.html',
  styleUrls: ['./citausuario.component.css']
})
export class CitausuarioComponent implements OnInit{


  ngOnInit() {

    this.obtenerTodosLosEstandares();
    this.listarMecanicos();

  }





  id_mecanico: number = 0;
  descripcion = "";
  calendarVisible = true;
  public id_usuario = this.authService.user.id;
  public id_usuario_string = String(this.id_usuario);
  datos;

  mecanico = new Mecanicomodelo(0,0, "");
  estandar = new Estandarmodelo( 0, new Date());


  get obtenerEstandares(){
    return this.reparacionesService.listaEstandarCitas;
  }



  capturarservicio() {
    // console.log(this.estandar.id);
    for(var prueba of this.obtenerEstandares ){
      if(prueba['id'] == this.estandar.id){
        const hora = String(prueba['duracion_estimada']);
         console.log(hora);
        console.log(this.estandar.id);
        this.calendarOptions.slotDuration = hora;

      }


    }



  }




  capturar() {
   const idmecanico = this.mecanico.usuario_id;
   this.id_mecanico = idmecanico;
   this.calendarOptions.events = 'http://127.0.0.1:8080/cita/obtener/' + this.id_mecanico;

  }


  // const { message, image,  publication_date } = this.miFormulario.value;
  private baseUrl: string = environment.baseUrl;
   // Cambiar por const mecanico.




  obtenerTodosLosEstandares(){
    this.reparacionesService.listarEstandaresCitas()
      .subscribe(resp => {
        if(resp){
          console.log(this.obtenerEstandares);
          console.log(resp);
        }else{
          console.log(resp);
        }
      });
  }
  calendarOptions: CalendarOptions = {
      plugins: [
        interactionPlugin,
        dayGridPlugin,
        timeGridPlugin,
        listPlugin,
      ],
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
      },
      initialView: 'timeGridWeek',
      // initialEvents: this.eventos, // alternatively, use the `events` setting to fetch from a feed
      weekends: false,
      editable: true,
      selectable: true,
      selectMirror: true,
      dayMaxEvents: true,
      select: this.handleDateSelect.bind(this),
      eventClick: this.handleEventClick.bind(this), // Borrar cuando saque id borrar descomentar.
      eventsSet: this.handleEvents.bind(this),
      // /* you can update a remote database when these fire:
      // eventAdd:

      events: `${this.baseUrl}/cita/obtener/${this.id_mecanico}`,



      // eventChange:
      // eventRemove:
      // */
    };

  currentEvents: EventApi[] = [];

  constructor(private toastr: ToastrService, private modalService: BsModalService, private changeDetector: ChangeDetectorRef, private reparacionesService: ReparacionesService, private citaService: CitaService, private mecanicoService: MecanicoService, private fb: FormBuilder, private authService: AuthService) {
  }

  handleCalendarToggle() {
    this.calendarVisible = !this.calendarVisible;
  }

  handleWeekendsToggle() {
    const { calendarOptions } = this;
    calendarOptions.weekends = !calendarOptions.weekends;
  }

  //Crear cita.
  handleDateSelect(selectInfo: DateSelectArg) {
    // const title = prompt('Por favor escriba su cita');
    const calendarApi = selectInfo.view.calendar;
    calendarApi.unselect(); // clear date selection
    // const title = 'Cita usuario.';
    Swal.fire({
      title: '¿Seguro que quieres reservar la siguiente cita?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: '¡Sí, Aceptar!'
    }).then((result) => {
      if (result.isConfirmed) {
        calendarApi.addEvent({
          id: createEventId(),
          start: selectInfo.startStr,
          end: selectInfo.endStr,
          allDay: selectInfo.allDay
        });
        if (this.id_mecanico == 0) {
          Swal.fire('Tienes que elegir un mecánico.');
          // this.toastr.error(`Tienes que elegir un mecánico`, 'Error');
          // this.mensajeAlert();
          // alert("Tienes que elegir un mecánico") ;
        }
        if (this.estandar.id == 0) {
          Swal.fire('Tienes que elegir una reparación');
          // this.toastr.error(`Tienes que elegir una reparación`, 'Error');
          // this.mensajeAlert2();
          // alert("Tienes que elegir una reparación") ;
        } else {
          this.cita.fecha_inicio = selectInfo.start;
          this.cita.fecha_fin = selectInfo.end;
          this.crearCita();
        }


      }
    })
  }



  // Borrar que solo pueda borrar las de su citas.
  handleEventClick(clickInfo: EventClickArg) {

      if (confirm(`¿Estás seguro que quieres borrar, ${clickInfo.event.title}?`)) {
        clickInfo.event.remove();
        this.borrarCitas(clickInfo.event.id );
      }
    }

  handleEvents(events: EventApi[]) {
    this.currentEvents = events;
    this.changeDetector.detectChanges();
  }

  cita = new Citamodelo(this.descripcion,new Date(),new Date());
  crearCita(){
    const mecanico = this.id_mecanico;
    const estandar = this.estandar.id;

    const { descripcion, fecha_inicio, fecha_fin } = this.cita;
    // const usermail = this.authService.usuario.username!;

    console.log(this.cita);



    this.citaService.crearCita(descripcion, fecha_inicio, fecha_fin, mecanico, estandar)
      .subscribe(resp => {
        if(resp){
          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          this.ngOnInit();
        }else{

        }
      })


  }

  get obtenerCitas(){
    return this.citaService.CitasObtener;
  }

  get obtenerMecanicos(){
    return this.mecanicoService.mecanicolistas;
  }

  listarMecanicos(){
    // const usermail = this.authService.usuario.username!;
    this.mecanicoService.obtenerMecanicos()
      .subscribe(resp =>{
        console.log(this.obtenerMecanicos)


      })
  }



  listarCita(){
    // const usermail = this.authService.usuario.username!;
    this.citaService.obtenerCitas()
      .subscribe(resp =>{

      })
  }

  borrarCitas(id: string) {
    this.citaService.borrarcita(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }

  mensajeAlert(){
    const alert = document.querySelector("#toast-danger")
    alert.classList.remove('hidden')
  }

  mensajeAlert2(){
    const alert = document.querySelector("#toast")
    alert.classList.remove('hidden')
  }



}
