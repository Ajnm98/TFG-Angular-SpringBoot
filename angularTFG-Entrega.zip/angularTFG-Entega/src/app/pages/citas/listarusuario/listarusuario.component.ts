import {ChangeDetectorRef, Component} from '@angular/core';
import {CitaService} from "../../../services/citas.service";
import {AuthService} from "../../../auth/service/auth.service";
import {Router} from "@angular/router";
import {ICreateOrderRequest} from "ngx-paypal";
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;


@Component({
  selector: 'app-listarusuario',
  templateUrl: './listarusuario.component.html',
  styleUrls: ['./listarusuario.component.css']
})
export class ListarusuarioComponent {

  //PAra el paypal
  public payPalConfig: any;
  public showPaypalButtons: boolean;
  public abrirpaypal: any;
  public cerrarpaypal: any;

  constructor(private changeDetector: ChangeDetectorRef, private citaService: CitaService, private router: Router) {
  }

  get obtenerCitasUsuario(){
    return this.citaService.CitasObtenerUsuario;
  }

  // private fecha_actual = new Date().toLocaleString();
   fecha_actual = new Date();

  pagarTienda(id: number) {
    this.citaService.updateCitas(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }




  private ngOnInit() {

    this.listarCita();

    this.payPalConfig = {
      payment: "10,00",
      currency: "EUR",

      clientId: "AUbUGNkizWyj07QwVN2Gd7-g29njNAmfJktfdbBXUsaAmoSAbMai7Lnw6bybViNObnjmE6d0IbRUH6Uu",
      createOrder: data =>
        <ICreateOrderRequest>{
          intent: "CAPTURE",
          purchase_units: [
            {
              amount: {
                currency_code: "USD",
                value: "15",
                breakdown: {
                  item_total: {
                    currency_code: "USD",
                    value: "15"
                  }
                }
              },
              items: [
                {
                  name: "Enterprise Subscription",
                  quantity: "3",
                  category: "DIGITAL_GOODS",
                  unit_amount: {
                    currency_code: "USD",
                    value: "9.99"
                  }
                }
              ]
            }
          ]
        },
      advanced: {
        commit: "true"
      },
      style: {
        label: "paypal",
        layout: "vertical"
      },
      transactions: [{
        amount: {
          currency: 'USD',
          total: 9
        }
      }],

      onApprove: (data, actions) => {
        console.log(
          "onApprove - transaction was approved, but not authorized",
          data,
          actions
        );
        actions.order.get().then(details => {
          console.log(
            "onApprove - you can get full order details inside onApprove: ",
            details
          );
        });
      },
      onClientAuthorization: data => {
        console.log(
          "onClientAuthorization - you should probably inform your server about completed transaction at this point",
          data
        );
        this.citaService.updateCitaspagado(this.abrirpaypal)
          .subscribe(resp => {
            this.ngOnInit();

          })
      //   const pdfDefinition: any = {
      //     content: [
      //       {
      //         text: 'Hola mundo',
      //       }
      //     ]
      //   }
      //
      //   const pdf = pdfMake.createPdf(pdfDefinition);
      //   pdf.open();
      //
      },
      onCancel: (data, actions) => {
        console.log("OnCancel", data, actions);
      },
      onError: err => {
        console.log("OnError", err);
      },
      onClick: (data, actions) => {
        console.log("onClick", data, actions);
      }
    };
  }

  pay(id: number) {
    this.showPaypalButtons = true;
    this.abrirpaypal = id;

  }

  back(id: number){
    this.showPaypalButtons = false;
    this.cerrarpaypal = id;
  }




  listarCita(){
    // const usermail = this.authService.usuario.username!;
    this.citaService.obtenerCitasUsuario()
      .subscribe(resp =>{
        console.log(this.obtenerCitasUsuario);
      })
  }

}
