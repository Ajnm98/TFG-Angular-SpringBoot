
export class Citamodelo {
  public someValue: string = '';

  constructor(
    public descripcion: string,
    public fecha_inicio: Date,
    public fecha_fin: Date){
  }
}
