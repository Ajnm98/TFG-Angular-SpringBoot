export class DatosUsuario {
    constructor(
        public nombre: string,
        public apellidos: string,
        public dni: string,
        public direccion: string,
        public telefono: string,
    ){}
}