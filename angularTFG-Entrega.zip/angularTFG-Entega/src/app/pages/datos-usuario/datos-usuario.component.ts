import { DatosUsuarioService } from './../../services/datosUsuario.service';
import { tap } from 'rxjs';
import { FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/service/auth.service';
import { DatosUsuario } from './datosUsuario';
import { Router } from '@angular/router';
import { Usuario } from '../../auth/interfaces/interface';

@Component({
  selector: 'app-datos-usuario',
  templateUrl: './datos-usuario.component.html',
  styleUrls: ['./datos-usuario.component.css']
})
export class DatosUsuarioComponent implements OnInit{

  constructor(private formBuilder: FormBuilder, 
    private datosUsuarioService: DatosUsuarioService, private auth: AuthService, private router: Router){}

    datosUsuario = new DatosUsuario("", "", "", "", "");
    user: Usuario;

    ngOnInit(): void {
      
    }

    

    crearDatosUsuario(){
      
      const { nombre, apellidos, dni, direccion, telefono } = this.datosUsuario;
      const id = this.auth.user.id!;

      const boton = document.querySelector('button')
      const formulario = document.querySelector('#loginform')
      const imagenGif = document.createElement('img')
      const spanGif = document.createElement('span')
      spanGif.textContent = 'Cargando ... '
      imagenGif.src = 'https://www.gifsanimados.org/data/media/67/coche-y-automovil-imagen-animada-0457.gif'
      spanGif.appendChild(imagenGif)

      
      this.datosUsuarioService.completarRegistro(nombre, apellidos, dni, direccion, telefono, id)
      .subscribe(resp => {
        if(resp){
          this.mensajeAlert()
          boton.remove()
          formulario.appendChild(spanGif)
          setTimeout(()=>{
            this.router.navigateByUrl('/dashboard/menu');
          },3000)
          this.ngOnInit()
        }
      });
    
    }

    mensajeAlert(){
      const alert = document.querySelector("#alert")
      alert.classList.remove('hidden')
    }

}