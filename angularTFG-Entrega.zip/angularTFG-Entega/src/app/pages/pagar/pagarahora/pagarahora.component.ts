import { Component } from '@angular/core';

@Component({
  selector: 'app-pagarahora',
  templateUrl: './pagarahora.component.html',
  styleUrls: ['./pagarahora.component.css']
})
export class PagarahoraComponent {



}
