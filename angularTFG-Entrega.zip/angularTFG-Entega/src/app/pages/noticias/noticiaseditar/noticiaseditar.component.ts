import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";

import {NoticiasService} from "../../../services/noticias.service";
import {Vehiculomodelo} from "../../vehiculo/vehiculomodelo";
import {Noticiasmodelo} from "../noticiasmodelo";
import {FormBuilder} from "@angular/forms";

@Component({
  selector: 'app-noticiaseditar',
  templateUrl: './noticiaseditar.component.html',
  styleUrls: ['./noticiaseditar.component.css']
})
export class NoticiaseditarComponent implements OnInit{

  constructor(private route: ActivatedRoute,
              private fb: FormBuilder,
              private router: Router,
              private noticiasService: NoticiasService) {

  }

  noticias = new Noticiasmodelo("","");

  get obtenerNoticia(){
    return this.noticiasService.noticiaslistaId!;
  }

  listarNoticiasEditar(){

    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.noticiasService.obtenerNoticiasid(id)
      .subscribe(resp =>{
        console.log(this.obtenerNoticia);
      })
  }



  ngOnInit() {
    this.listarNoticiasEditar();
  }


  editarNoticias(){
    const { titular, cuerpo } = this.noticias;
    const id = Number(this.route.snapshot.paramMap.get('id'));

    console.log(this.noticias);

    this.noticiasService.editarNoticias(titular, cuerpo, id)
      .subscribe(resp => {
        if(resp){
          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          this.ngOnInit();
        }else{

        }
      })
  }


}
