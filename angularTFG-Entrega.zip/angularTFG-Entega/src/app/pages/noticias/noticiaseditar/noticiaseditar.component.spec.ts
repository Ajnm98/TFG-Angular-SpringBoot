import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticiaseditarComponent } from './noticiaseditar.component';

describe('NoticiaseditarComponent', () => {
  let component: NoticiaseditarComponent;
  let fixture: ComponentFixture<NoticiaseditarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoticiaseditarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NoticiaseditarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
