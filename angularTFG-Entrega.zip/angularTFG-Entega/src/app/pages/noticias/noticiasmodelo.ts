export class Noticiasmodelo {
  public someValue: string = '';

  constructor(
    public titular: string,

    public cuerpo: string) {
  }
}
