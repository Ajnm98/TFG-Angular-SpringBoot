export class Noticiaseditarmodelo {
  public someValue: string = '';

  constructor(

    public id: number,
    public titular: string,

    public cuerpo: string) {
  }
}
