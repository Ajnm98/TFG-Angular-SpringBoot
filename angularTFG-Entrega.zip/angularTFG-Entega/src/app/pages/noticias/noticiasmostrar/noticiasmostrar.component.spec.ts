import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticiasmostrarComponent } from './noticiasmostrar.component';

describe('NoticiasmostrarComponent', () => {
  let component: NoticiasmostrarComponent;
  let fixture: ComponentFixture<NoticiasmostrarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoticiasmostrarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NoticiasmostrarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
