import { noticias } from './../../../interfaces/interfaceNoticias';
import { Component } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {NoticiasService} from "../../../services/noticias.service";
import {AuthService} from "../../../auth/service/auth.service";
import {mecanicoObtener} from "../../../interfaces/interfaceMecanico";
import {catchError, map, of} from "rxjs";
import {FormBuilder} from "@angular/forms";
import { Usuario } from '../../../auth/interfaces/interface';
import { DatosUsuarioService } from 'src/app/services/datosUsuario.service';
import { DatosUsuario } from 'src/app/pages/datos-usuario/datosUsuario';



@Component({
  selector: 'app-noticiasmostrar',
  templateUrl: './noticiasmostrar.component.html',
  styleUrls: ['./noticiasmostrar.component.css']
})
export class NoticiasmostrarComponent {

  role: string = '';

  getRole(){
    const roles = this.auth.user.roles
    roles.forEach(element => {
      if(element.name === 'ROLE_ADMIN'){
        this.role = element.name;
      }
    });
    // const roles1 = this.auth.user.roles[0]["name"]
    // const roles2 = this.auth.user.roles[1]["name"]
  }

  usuarioAuth : Usuario
  usuario : DatosUsuario = new DatosUsuario('','', '', '','');

  constructor(private fb: FormBuilder,
              private noticiasService: NoticiasService, private authService: AuthService, private router: Router,
              private auth: AuthService, private datosUsuario: DatosUsuarioService) {
  }

  get obtenerNoticias(){
    return this.noticiasService.noticiaslistas;
  }

  private ngOnInit() {
    this.getRole()
    this.listarNoticias();
    this.datosUsuarioObtener()
  }


  datosUsuarioObtener(){
    const usuarioId = this.auth.user.id; // ID del usuario que deseas obtener
    this.usuarioAuth = this.auth.user;
    const completar_registro = document.querySelector('#completar-registro')
    this.datosUsuario.getDatosUsuario(usuarioId).subscribe(
      (usuario: DatosUsuario) => {
        this.usuario.nombre = usuario.nombre;
        this.usuario.apellidos = usuario.apellidos;
        this.usuario.telefono = usuario.telefono;
        this.usuario.direccion = usuario.direccion;
        this.usuario.dni = usuario.dni; 
        if(usuario){
          completar_registro.remove()
        }
        // Aquí puedes realizar otras operaciones con el usuario
      },
      error => {
        // Manejo de errores
      })

  }



  listarNoticias(){
    console.log(this.obtenerNoticias);
    this.noticiasService.obtenerNoticias()
      .subscribe(resp =>{

      })
  }


  borrarNoticias(id: number) {
    console.log(id)
    this.noticiasService.borrarNoticias(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }


  onEditProfile(id: number) {

    this.router.navigateByUrl('dashboard/noticias/editar/' +id)
  }

  verNoticia(id: number) {

    this.router.navigateByUrl('dashboard/noticias/ver/' +id)
  }


}
