import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticiasverComponent } from './noticiasver.component';

describe('NoticiasverComponent', () => {
  let component: NoticiasverComponent;
  let fixture: ComponentFixture<NoticiasverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoticiasverComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NoticiasverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
