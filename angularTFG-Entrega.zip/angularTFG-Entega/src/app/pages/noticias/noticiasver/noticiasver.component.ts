import { Component } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {FormBuilder} from "@angular/forms";
import {NoticiasService} from "../../../services/noticias.service";
import {Noticiasmodelo} from "../noticiasmodelo";

@Component({
  selector: 'app-noticiasver',
  templateUrl: './noticiasver.component.html',
  styleUrls: ['./noticiasver.component.css']
})
export class NoticiasverComponent {
  constructor(private route: ActivatedRoute,
              private fb: FormBuilder,
              private router: Router,
              private noticiasService: NoticiasService) {

  }

  noticias = new Noticiasmodelo("", "");

  get obtenerNoticia() {
    return this.noticiasService.noticiaslistaId!;
  }

  listarNoticiasEditar() {

    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.noticiasService.obtenerNoticiasid(id)
      .subscribe(resp => {
        console.log(this.obtenerNoticia);
      })
  }

  borrarNoticias(id: number) {
    console.log(id)
    this.noticiasService.borrarNoticias(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }


  onEditProfile(id: number) {

    this.router.navigateByUrl('dashboard/noticias/editar/' +id)
  }


  ngOnInit() {
    this.listarNoticiasEditar();
  }

}
