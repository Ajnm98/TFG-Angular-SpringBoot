import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticiascrearComponent } from './noticiascrear.component';

describe('NoticiascrearComponent', () => {
  let component: NoticiascrearComponent;
  let fixture: ComponentFixture<NoticiascrearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoticiascrearComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NoticiascrearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
