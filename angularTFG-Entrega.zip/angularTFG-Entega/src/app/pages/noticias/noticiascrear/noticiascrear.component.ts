
import { AuthService } from './../../../auth/service/auth.service';
import {Component, NgModule, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {NoticiasService} from 'src/app/services/noticias.service'
import { ReactiveFormsModule } from '@angular/forms';

import {Noticiasmodelo} from "../noticiasmodelo";
@Component({
  selector: 'app-noticiascrear',
  templateUrl: './noticiascrear.component.html',
  styleUrls: ['./noticiascrear.component.css']
})

export class NoticiascrearComponent implements OnInit{
  public someValue:string= '';

  constructor(private fb: FormBuilder,
              private noticiasService: NoticiasService, private authService: AuthService) {
  }

  noticias = new Noticiasmodelo("","");

  ngOnInit(): void {

  }

  mensajeAlert(){
    const alert = document.querySelector("#alert")
    alert.classList.remove('hidden')
    console.log('correcto')
    setTimeout(()=> {
      alert.classList.add('hidden')
    },3000)
  }
  
  crearNoticia(){
    const { titular, cuerpo } = this.noticias;


    console.log(this.noticias);

    this.noticiasService.crearNoticias(titular, cuerpo)
      .subscribe(resp => {
        if(resp){
          this.mensajeAlert()
          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          this.ngOnInit();
        }else{

        }
      })
  }




}
