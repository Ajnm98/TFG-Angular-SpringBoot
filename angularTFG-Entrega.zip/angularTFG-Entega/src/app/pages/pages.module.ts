import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './../app-routing.module';
import { ComponentsModule } from './../components/components.module';
import { SharedModule } from './../shared/shared.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Grafica1Component } from './grafica1/grafica1.component';
import { PagesComponent } from './pages.component';
// import { ProgressComponent } from './progress/progress.component';
import { AccountSettingsComponent } from './account-settings/account-settings.component';
import { VehiculomostrarComponent } from './vehiculo/vehiculomostrar/vehiculomostrar.component';
import { VehiculoeditarComponent } from './vehiculo/vehiculoeditar/vehiculoeditar.component';
// import { CitasComponent } from './citas/citas.component';
import { PagesRoutingModule } from './pages.routing';
import { ReparacionesEstandarComponent } from './reparaciones-estandar/reparaciones-estandar.component';
import {ProgressComponent} from "./progress/progress.component";
import {CitausuarioComponent} from "./citas/citausuario/citausuario.component";
import {CitasComponent} from "./citas/citas.component";
import {VehiculoComponent} from "./vehiculo/vehiculocrear/vehiculo.component";
import {FullCalendarModule} from "@fullcalendar/angular";
import {NgxPayPalModule} from "ngx-paypal";
import { MecanicoComponent } from './mecanico/mecanicocrear/mecanico.component';
import {MecanicomostrarComponent} from "./mecanico/mecanicomostrar/mecanicomostrar.component";
import { MecanicoeditarComponent } from './mecanico/mecanicoeditar/mecanicoeditar.component';
import { ListarusuarioComponent } from './citas/listarusuario/listarusuario.component';
import { PagarahoraComponent } from './pagar/pagarahora/pagarahora.component';
import { DatosUsuarioComponent } from './datos-usuario/datos-usuario.component';
import { PerfilUsuarioComponent } from './perfil-usuario/perfil-usuario.component';
import {NoticiascrearComponent} from "./noticias/noticiascrear/noticiascrear.component";
import { NoticiasmostrarComponent } from './noticias/noticiasmostrar/noticiasmostrar.component';
import { NoticiaseditarComponent } from './noticias/noticiaseditar/noticiaseditar.component';
import { UsuariomostrarComponent } from './usuario/usuariomostrar/usuariomostrar.component';
import { UsuarioeditarComponent } from './usuario/usuarioeditar/usuarioeditar.component';
import { NoticiasverComponent } from './noticias/noticiasver/noticiasver.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FaqComponent } from './faq/faq.component';


@NgModule({
  declarations: [
    ProgressComponent,
    Grafica1Component,
    PagesComponent,
    DashboardComponent,
    AccountSettingsComponent,
    VehiculoeditarComponent,
    ReparacionesEstandarComponent,
    VehiculoComponent,
    VehiculomostrarComponent,
    CitasComponent,
    CitausuarioComponent,
    MecanicoComponent,
    MecanicomostrarComponent,
    MecanicoeditarComponent,
    MecanicoeditarComponent,
    DatosUsuarioComponent,
    PerfilUsuarioComponent,
    NoticiascrearComponent,
    NoticiasmostrarComponent,
    NoticiaseditarComponent,
    UsuariomostrarComponent,
    UsuarioeditarComponent,
    NoticiasverComponent,
    ContactUsComponent,
    FaqComponent,
    ListarusuarioComponent,
    PagarahoraComponent,
    // CitasComponent
  ],
  exports: [
    // ProgressComponent,
    Grafica1Component,
    PagesComponent,
    DashboardComponent,
    AccountSettingsComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ComponentsModule,
    RouterModule,
    PagesRoutingModule,
    ReactiveFormsModule,
    FullCalendarModule,
    NgxPayPalModule
  ]
})
export class PagesModule { }
