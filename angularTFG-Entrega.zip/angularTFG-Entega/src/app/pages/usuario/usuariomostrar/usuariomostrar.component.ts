import { Component } from '@angular/core';
import {FormBuilder} from "@angular/forms";
import {NoticiasService} from "../../../services/noticias.service";
import {AuthService} from "../../../auth/service/auth.service";
import {Router} from "@angular/router";
import {UsuarioService} from "../../../services/usuario.service";

@Component({
  selector: 'app-usuariomostrar',
  templateUrl: './usuariomostrar.component.html',
  styleUrls: ['./usuariomostrar.component.css']
})
export class UsuariomostrarComponent {


  constructor(private fb: FormBuilder,
              private usuarioService: UsuarioService, private authService: AuthService, private router: Router) {
  }

  get obtenerUsuario(){
    return this.usuarioService.usuariolistas;
  }

  private ngOnInit() {
    this.listarUsuario();
  }


  listarUsuario(){
    console.log(this.obtenerUsuario);
    this.usuarioService.obtenerUsuarios()
      .subscribe(resp =>{

      })
  }


  borrarUsuario(id: number) {
    console.log(id)
    this.usuarioService.borrarUsuario(id)
      .subscribe(resp => {
        this.ngOnInit();
      })
  }


  onEditProfile(id: number) {

    this.router.navigateByUrl('dashboard/usuario/editar/' +id)
  }


}
