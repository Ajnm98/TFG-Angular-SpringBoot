import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsuariomostrarComponent } from './usuariomostrar.component';

describe('UsuariomostrarComponent', () => {
  let component: UsuariomostrarComponent;
  let fixture: ComponentFixture<UsuariomostrarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsuariomostrarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsuariomostrarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
