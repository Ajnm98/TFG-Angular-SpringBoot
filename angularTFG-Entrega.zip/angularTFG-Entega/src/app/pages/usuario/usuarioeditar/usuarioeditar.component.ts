import { Component } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {FormBuilder} from "@angular/forms";

import {Noticiasmodelo} from "../../noticias/noticiasmodelo";
import {UsuarioService} from "../../../services/usuario.service";
import {Usuariomodelo} from "../usuariomodelo";

@Component({
  selector: 'app-usuarioeditar',
  templateUrl: './usuarioeditar.component.html',
  styleUrls: ['./usuarioeditar.component.css']
})
export class UsuarioeditarComponent {


  constructor(private route: ActivatedRoute,
              private fb: FormBuilder,
              private router: Router,
              private usuarioService: UsuarioService) {

  }

  usuario = new Usuariomodelo("","", "");

  get obtenerUsuario(){
    return this.usuarioService.usuariolistaId!;
  }

  listarUsuarioEditar(){

    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.usuarioService.obtenerUsuarioid(id)
      .subscribe(resp =>{
        console.log(this.obtenerUsuario);
      })
  }



  ngOnInit() {
    this.listarUsuarioEditar();
  }


  editarUsuario(){
    const { username, password, email } = this.usuario;
    const id = Number(this.route.snapshot.paramMap.get('id'));

    console.log(this.usuario);

    this.usuarioService.editarUsuario(username, password, email, id)
      .subscribe(resp => {
        if(resp){
          //ejecutamos onInit para refrescar la página y aparezca el mensaje.
          this.ngOnInit();
        }else{

        }
      })
  }
}
