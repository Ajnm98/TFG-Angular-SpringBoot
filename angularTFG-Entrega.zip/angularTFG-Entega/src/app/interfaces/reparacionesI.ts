export interface createEstandar {
    status: string;
    code: string;
    message: string;
    data?: EstandarReparacion | null;
  }

  export interface EstandarReparacion {
    id?: number;
    nombre?: string;
    descripcion?: string;
    precio_estimado?: number;
    duracion_estimada?: string;
    reparaciones?: string | null;
  }


  export interface listarEstandares {
    status: string;
    code: string;
    message: string;
    data?: EstandarReparacion[] | null;
  }

