export interface vehiculoCrear {
  status?: string;
}
export interface vehiculoBorrar {
  status?: string;
}
export interface vehiculoUsuario{
  vehiculoUsuario: VehiculoUsuario[];
}

export interface vehiculoUsuariolista{
  vehiculoUsuariolista: VehiculoUsuario[];
}

export interface VehiculoUsuario {
  id?: number;
  tipoVehiculo?: string;
  tipoCombustible?: string;
  modeloVehiculo?: string;
  fecha_creacion?: Date;
  matricula?: string;
}