

export interface mecanicoCrear {
  status?: string;
}

export interface mecanicoObtener{
  mecanicoObtener: mecanicolista[];
}

export interface mecanicolista {
  id?: number;
  nombre?: string;
  apellidos?: string;
  especialidad?: string;
  identificacion?: string;
  usuario?: usuario;
}

export interface usuario {
  id?: number;
}


export interface mecanicoListaId{
  mecanicoListaId: mecanicolista[];
}
