import { Usuario } from '../auth/interfaces/interface';

export interface DatosUsuario{
    nombre: string;
    apellidos: string;
    dni: string;
    direccion: string;
    telefono:string;
    Usuario?:  Usuario;
}