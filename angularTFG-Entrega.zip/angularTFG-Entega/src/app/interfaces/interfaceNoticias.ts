import {VehiculoUsuario} from "./interfaceVehiculo";
import {mecanicolista} from "./interfaceMecanico";

export interface noticiasCrear {
  status?: string;
}

export interface noticiasObtener{
  noticiasObtener: noticias[];
}



export interface noticiaslista{
  noticiaslista: noticias[];
}


export interface noticias {
  id?: number;
  titular?: string;

  cuerpo?: string;
}

export interface noticiasListaId{
  noticiasListaId: noticias[];
}

