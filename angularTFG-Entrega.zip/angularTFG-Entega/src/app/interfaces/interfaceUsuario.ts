export interface usuarioCrear {
  status?: string;
}

export interface usuarioObtener{
  usuarioObtener: usuario[];
}



export interface usuariolista{
  usuariolista: usuario[];
}


export interface usuario {
  id?: number;
  username?: string;

  password?: string;

  email?: string;
}

export interface usuarioListaId{
  usuarioListaId: usuario[];
}
