

export interface citaCrear {
  status?: string;
}


export interface citasObtener{
  citasObtener: citas[];
}


export interface citasObtenerUsuario{
  citasObtenerUsuario: citasUsuario[];
}
export interface citas {
  id?: number;
  fecha_inicio?: Date;
  fecha_fin?: Date;
  descripcion?: string;
}


export interface citasUsuario {
  id?: number;
  start?: Date;
  end?: Date;
  estandarReparacion: reparacion;
  title?: string;
  pagar_ahora?: number,
  pagar_tienda?: number
}

export interface reparacion {
  nombre: reparacion;
  descripcion?: string;
  duracion_estimada?: string,
  precio_estimado?: number,
}

