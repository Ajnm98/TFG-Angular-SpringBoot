import { SidebarService } from './../../services/sidebar.service';
import { Component, OnInit } from '@angular/core';
import {MecanicoService} from "../../services/mecanico.service";
import { AuthService } from 'src/app/auth/service/auth.service';
import { DatosUsuario } from 'src/app/pages/datos-usuario/datosUsuario';
import { DatosUsuarioService } from 'src/app/services/datosUsuario.service';
import { Usuario } from './../../auth/interfaces/interface';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styles: [
  ]
})
export class SidebarComponent implements OnInit{

  constructor(private sidebarService: SidebarService, private auth: AuthService,
    private datosUsuario: DatosUsuarioService){
    this.menuItems = sidebarService.menu;
  }

  role: string = '';

  getRole(){
    const roles = this.auth.user.roles
    roles.forEach(element => {
      if(element.name === 'ROLE_ADMIN' || element.name === 'ROLE_MECANICO'){
        this.role = element.name;
      }
    });
    // const roles1 = this.auth.user.roles[0]["name"]
    // const roles2 = this.auth.user.roles[1]["name"]
  }

  // rolesID = this.auth.user.roles[1]["id"]

  usuarioAuth : Usuario
  usuario : DatosUsuario = new DatosUsuario('','', '', '','');

  ngOnInit(): void {
    const usuarioId = this.auth.user.id; // ID del usuario que deseas obtener
    this.usuarioAuth = this.auth.user;
    this.getRole()
    this.datosUsuario.getDatosUsuario(usuarioId).subscribe(
      (usuario: DatosUsuario) => {
        this.usuario = usuario;
        // Aquí puedes realizar otras operaciones con el usuario
      },
      error => {
        console.error(error);
        // Manejo de errores
      }
    );
  }

  menuItems: any[];




}
