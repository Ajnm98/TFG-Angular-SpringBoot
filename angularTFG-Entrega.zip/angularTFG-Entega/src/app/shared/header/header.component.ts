import { Usuario } from './../../auth/interfaces/interface';

import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/service/auth.service';
import { DatosUsuario } from 'src/app/pages/datos-usuario/datosUsuario';
import { DatosUsuarioService } from 'src/app/services/datosUsuario.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styles: [
  ]
})
export class HeaderComponent implements OnInit{
  
  constructor(private auth: AuthService,private datosUsuario: DatosUsuarioService) {
    
  }

  usuarioAuth : Usuario
  usuario : DatosUsuario = new DatosUsuario('','', '', '','');

  ngOnInit(): void {
    const usuarioId = this.auth.user.id; // ID del usuario que deseas obtener
    this.usuarioAuth = this.auth.user;

    this.datosUsuario.getDatosUsuario(usuarioId).subscribe(
      (usuario: DatosUsuario) => {
        this.usuario = usuario;
        // Aquí puedes realizar otras operaciones con el usuario
      },
      error => {
        console.error(error);
        // Manejo de errores
      }
    );
  }

}
